import json
import google.generativeai as genai
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()
genai.configure(api_key=os.getenv("AIzaSyAm34W4HZbjIzM8G0MsTbDbQ5lJVcvc5cU"))

# Load SLM data
with open('data.json', 'r') as file:
    data = json.load(file)

# Function to get answer
def get_answer(question):
    # Check if question exists in local SLM
    if question in data:
        return data[question]
    
    # Otherwise, query Gemini
    model = genai.GenerativeModel("gemini-2.5-flash")
    response = model.generate_content(question)
    answer = response.text

    # Optionally, save the new Q&A to JSON for future
    data[question] = answer
    with open('data.json', 'w') as file:
        json.dump(data, file, indent=4)
    
    return answer

# Example usage
question = input("Ask a question: ")
answer = get_answer(question)
print("\nAnswer:", answer)

