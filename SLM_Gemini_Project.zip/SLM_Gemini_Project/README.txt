Instructions to run the project:

1. Install required Python packages:
   pip install google-generativeai python-dotenv

2. Replace YOUR_API_KEY_HERE in .env with your own Gemini API key.

3. Run the main program:
   python slm_gemini.py

4. The program will ask for a question and return an answer using the local JSON or Gemini AI.
